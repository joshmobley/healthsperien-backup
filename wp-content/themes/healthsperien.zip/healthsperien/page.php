<?php
    $fields = get_fields();
?>

<?php get_header(); ?>

<?php include('includes/content/parser.php'); ?>

<?php get_footer(); ?>
