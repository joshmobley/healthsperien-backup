<head>
    <title>Healthsperien</title>
    <link href="<?php echo get_template_directory_uri(); ?>/reset.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss/dist/utilities.min.css" rel="stylesheet" />
    <link href="<?php echo get_template_directory_uri(); ?>/style.css" rel="stylesheet" />
</head>
