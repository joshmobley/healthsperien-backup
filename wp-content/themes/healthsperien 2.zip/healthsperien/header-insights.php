<!DOCTYPE html>
<html>
    <?php include('includes/head.php'); ?>
<body>
    <header class="banner banner--small">

        <?php include('includes/nav.php');?>

    </header>
